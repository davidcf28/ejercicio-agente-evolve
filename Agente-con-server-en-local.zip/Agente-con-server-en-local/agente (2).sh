#!/usr/bin/env bash
# agente.sh - recoge el estado de los recursos y lo envía por webhook al canal "monitor".
# Uso: ./agente.sh [-i segundos] [-u url_webhook] [-n nombre_de_host]
export LC_ALL=C

INTERVALO=10
NOMBRE=$(hostname)
URL="${MONITOR_URL:-http://localhost:8080/webhook/monitor}"   # <-- ajusta a la URL real del webhook
LOG="agente.log"

while getopts "i:u:n:h" op; do
  case $op in
    i) INTERVALO=$OPTARG ;;
    u) URL=$OPTARG ;;
    n) NOMBRE=$OPTARG ;;
    *) echo "Uso: $0 [-i segundos] [-u url] [-n nombre]"; exit 1 ;;
  esac
done
[[ $INTERVALO =~ ^[0-9]+$ ]] || { echo "-i debe ser un entero" >&2; exit 1; }

log() { echo "$(date -u +%FT%TZ) $*" >> "$LOG"; }

# user nice system idle iowait irq softirq steal -> "idle total"
leer_cpu() {
  awk '/^cpu /{ idle=$5+$6; total=0; for(i=2;i<=9;i++) total+=$i; print idle, total }' /proc/stat
}

recoger() {
  # --- CPU: dos lecturas separadas 1 s ---
  read -r i1 t1 < <(leer_cpu)
  sleep 1
  read -r i2 t2 < <(leer_cpu)
  cpu=$(awk -v i1="$i1" -v t1="$t1" -v i2="$i2" -v t2="$t2" \
    'BEGIN{ dt=t2-t1; di=i2-i1; printf "%.1f", (dt>0) ? 100*(dt-di)/dt : 0 }')

  # --- Memoria (kB -> MB) ---
  read -r mt mu mp < <(awk '/^MemTotal/{t=$2} /^MemAvailable/{a=$2}
    END{ printf "%d %d %.1f\n", t/1024, (t-a)/1024, (t>0)?100*(t-a)/t:0 }' /proc/meminfo)

  # --- Disco: "montaje pct" por línea -> array JSON ---
  disco=$(df -P -x tmpfs -x devtmpfs -x squashfs -x overlay 2>/dev/null | awk 'NR>1{ gsub("%","",$5); print $6, $5 }' |
    jq -R -s -c 'split("\n") | map(select(length>0) | split(" ") | {montaje:.[0], pct:(.[1]|tonumber)})')

  # --- Carga y uptime ---
  read -r l1 l2 l3 _ < /proc/loadavg
  up=$(awk '{ print int($1) }' /proc/uptime)

  # --- Top 3 procesos por CPU ---
  top=$(ps -eo pid,comm,%cpu --sort=-%cpu | awk 'NR>1 && NR<=4' |
    jq -R -s -c 'split("\n") | map(select(length>0) | split(" ") | map(select(length>0))
                 | {pid:(.[0]|tonumber), cmd:.[1], cpu:(.[2]|tonumber)})')

  jq -n -c \
    --arg host "$NOMBRE" \
    --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --argjson cpu "$cpu" \
    --argjson mt "$mt" --argjson mu "$mu" --argjson mp "$mp" \
    --argjson disco "${disco:-[]}" \
    --argjson l1 "$l1" --argjson l2 "$l2" --argjson l3 "$l3" \
    --argjson up "$up" \
    --argjson top "${top:-[]}" \
    '{host:$host, ts:$ts, cpu_pct:$cpu,
      mem:{total_mb:$mt, usada_mb:$mu, pct:$mp},
      disco:$disco, carga:[$l1,$l2,$l3], uptime_s:$up, top_procesos:$top}'
}

trap 'log "agente detenido"; exit 0' INT TERM
log "agente iniciado (intervalo=${INTERVALO}s, url=$URL)"

while true; do
  inicio=$(date +%s)
  json=$(recoger)
  if [[ -z $json ]]; then
    log "ERROR: no se pudo construir el JSON"
  elif ! err=$(curl -sS -f -m 5 -X POST -H 'Content-Type: application/json' -d "$json" "$URL" 2>&1 >/dev/null); then
    log "ERROR de envío: $err"
  fi
  # la recogida ya consume ~1 s; descontamos lo que haya tardado
  resto=$(( INTERVALO - ($(date +%s) - inicio) ))
  (( resto > 0 )) && sleep "$resto"
done
