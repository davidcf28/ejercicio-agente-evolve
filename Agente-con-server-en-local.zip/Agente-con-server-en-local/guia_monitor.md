# Guía paso a paso: monitorización de recursos con panel

## Paso 1: preparar la carpeta

Copia los 4 ficheros a una carpeta, por ejemplo `~/monitor`, y entra:

```bash
mkdir -p ~/monitor && cd ~/monitor
chmod +x agente.sh panel.sh
```

## Paso 2: instalar Apache y jq

```bash
sudo apt update
sudo apt install -y apache2 jq
```

## Paso 3: arrancar Apache y darle permisos

```bash
sudo systemctl start apache2
sudo chown $USER /var/www/html
```

El `chown` es para que `panel.sh` pueda escribir `index.html` ahí sin `sudo`. Comprueba que Apache responde:

```bash
curl -I http://localhost
```

Debe salir `HTTP/1.1 200 OK`.

## Paso 4: arrancar el receptor (terminal 1)

```bash
cd ~/monitor
python3 receptor.py
```

Déjalo abierto. Mostrará una línea por cada informe que reciba. Por defecto solo acepta conexiones de tu propia máquina; para que lo usen otros equipos, `python3 receptor.py --bind 0.0.0.0`.

## Paso 5: lanzar 3 agentes simulados (terminal 2)

```bash
cd ~/monitor
./agente.sh -n kali-g1 -i 5 &
./agente.sh -n kali-g2 -i 5 &
./agente.sh -n kali-g3 -i 5 &
```

Cada uno se hace pasar por un equipo distinto, pero los tres miden tu misma máquina. Con `-i 5` mandan un informe cada 5 segundos. Para comprobar que llegan: `curl -s localhost:8080/canal/monitor | jq length`.

## Paso 6: ver el panel

**En terminal (terminal 3):**

```bash
cd ~/monitor
./panel.sh
```

**En web:**

```bash
./panel.sh --html -o /var/www/html
```

Abre `http://localhost` en el navegador. Se recarga solo cada 5 segundos. Si compartes tu IP, otros equipos de la misma red pueden verlo en `http://TU_IP`.

## Paso 7: pruebas de "Hecho cuando..."

1. **CPU en rojo:** en otra terminal, `yes > /dev/null &`. En menos de 15 segundos la CPU de los hosts se pone en rojo. Como los tres agentes miden la misma máquina, se ponen rojos a la vez. Para pararlo: `kill %1` (o `pkill yes`).
2. **Equipo CAÍDO:** `kill %2` en la terminal de los agentes. A los 30 segundos `kali-g2` pasa a gris con CAIDO.
3. **Alertas:** comprueba que solo se publican al cambiar de estado:

   ```bash
   curl -s localhost:8080/canal/alertas | jq '.[].datos'
   ```

4. **Umbrales:** edita `umbrales.json` (por ejemplo `"rojo": 50`) con el panel en marcha y verás el cambio en el siguiente ciclo.

## Paso 8: parar todo

```bash
pkill -f agente.sh
pkill yes
sudo systemctl stop apache2     # no lo dejes activo al terminar
```

Y Ctrl+C en el receptor y en el panel.

## Para la demo con otros equipos

Cuando los compañeros ejecuten su agente en su máquina, tienen que apuntar a tu IP:

```bash
./agente.sh -i 5 -u http://TU_IP:8080/webhook/monitor
```
