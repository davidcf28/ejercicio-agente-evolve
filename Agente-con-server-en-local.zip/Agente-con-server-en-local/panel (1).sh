#!/usr/bin/env bash
# panel.sh - lee el canal "monitor" y muestra el ultimo informe de cada host.
#   Modo terminal (por defecto) o web con --html (genera index.html con autorrecarga).
# Fase 2: umbrales.json, mini-grafica de CPU (20 informes), alertas al cambiar de estado, panel web.
#
# Uso: ./panel.sh [--html] [-o carpeta_salida] [-c url_canal] [-a url_alertas] [-u umbrales.json] [-r segundos]
export LC_ALL=C

CANAL_URL="${MONITOR_CANAL_URL:-http://localhost:8080/canal/monitor}"
ALERTAS_URL="${MONITOR_ALERTAS_URL:-http://localhost:8080/webhook/alertas}"
UMBRALES="umbrales.json"
REFRESCO=5
SALIDA_DIR="."
LOG="panel.log"
MODO=terminal

# --html es una opcion larga: getopts no la entiende, asi que la separamos antes
args=()
for a in "$@"; do
  if [[ $a == --html ]]; then MODO=html; else args+=("$a"); fi
done
set -- "${args[@]}"

while getopts "c:a:u:r:o:h" op; do
  case $op in
    c) CANAL_URL=$OPTARG ;;
    a) ALERTAS_URL=$OPTARG ;;
    u) UMBRALES=$OPTARG ;;
    r) REFRESCO=$OPTARG ;;
    o) SALIDA_DIR=$OPTARG ;;
    *) echo "Uso: $0 [--html] [-o carpeta] [-c url_canal] [-a url_alertas] [-u umbrales.json] [-r segundos]"; exit 1 ;;
  esac
done

COL=($'\033[32m' $'\033[33m' $'\033[31m' $'\033[90m')   # verde, amarillo, rojo, gris
RST=$'\033[0m'
NOMBRE=(OK AMARILLO ROJO CAIDO)
declare -A ESTADO   # ultimo nivel conocido por host (para alertar solo al cambiar)
TMP=$(mktemp)

log() { echo "$(date -u +%FT%TZ) $*" >> "$LOG"; }
esc() { jq -rn --arg t "$1" '$t | @html'; }   # escapa texto para HTML

cargar_umbrales() {
  U_AMA=60; U_ROJO=85; U_CAIDO=30
  if [[ -r $UMBRALES ]]; then
    read -r a r c < <(jq -r '[(.amarillo // 60), (.rojo // 85), (.caido_s // 30)] | @tsv' "$UMBRALES" 2>/dev/null)
    U_AMA=${a:-60}; U_ROJO=${r:-85}; U_CAIDO=${c:-30}
  fi
}

# 0 = verde (< amarillo), 1 = amarillo (hasta rojo), 2 = rojo (> rojo)
nivel() {
  awk -v v="$1" -v a="$U_AMA" -v r="$U_ROJO" 'BEGIN{ print (v<a) ? 0 : ((v<=r) ? 1 : 2) }'
}

alertar() {  # host anterior nuevo cpu mem
  local json
  json=$(jq -n -c --arg host "$1" --arg ant "${NOMBRE[$2]}" --arg nue "${NOMBRE[$3]}" \
    --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" --argjson cpu "$4" --argjson mem "$5" \
    '{host:$host, anterior:$ant, nuevo:$nue, ts:$ts, cpu_pct:$cpu, mem_pct:$mem}')
  curl -sS -f -m 5 -X POST -H 'Content-Type: application/json' -d "$json" "$ALERTAS_URL" \
    >/dev/null 2>>"$LOG" || log "ERROR enviando alerta de $1"
}

# Ultimo informe por host + sparkline de CPU de los ultimos 20 informes.
FILTRO='
def spark: ["▁","▂","▃","▄","▅","▆","▇","█"] as $c
  | map($c[([((. / 12.5) | floor), 7] | min)]) | join("");
map(select(.datos.host != null))
| group_by(.datos.host)
| .[]
| sort_by(.datos.ts) as $g
| $g[-1].datos as $d
| [ $d.host, $d.cpu_pct, $d.mem.pct,
    ([$d.disco[] | select(.montaje == "/") | .pct] | first // 0),
    $d.carga[0], $d.ts,
    ($now - ($d.ts | fromdateiso8601)),
    ($g | map(.datos.cpu_pct) | .[-20:] | spark) ]
| @tsv'

# ---------- salida en terminal ----------
term_cabecera() {
  printf 'MONITOR DE RECURSOS   %s   (amarillo>=%s%%  rojo>%s%%  caido>%ss)\n\n' \
    "$(date '+%H:%M:%S')" "$U_AMA" "$U_ROJO" "$U_CAIDO"
  printf '%-14s %7s %7s %7s %6s  %-8s %6s  %s\n' HOST CPU MEM "DISCO /" CARGA HORA EDAD "CPU(20)"
  printf -- '------------------------------------------------------------------------------\n'
}

fila_term() {   # usa las variables de procesar()
  if (( n_glob == 3 )); then
    printf '%s%-14s CAIDO  (ultimo informe hace %ss, a las %s)%s\n' "${COL[3]}" "$host" "$edad" "${ts:11:8}" "$RST"
  else
    printf '%-14s %s%6.1f%%%s %s%6.1f%%%s %s%6.0f%%%s %6.2f  %-8s %5ss  %s%s%s  %s%s%s\n' \
      "$host" \
      "${COL[$n_cpu]}" "$cpu" "$RST" \
      "${COL[$n_mem]}" "$mem" "$RST" \
      "${COL[$n_dis]}" "$disco" "$RST" \
      "$carga" "${ts:11:8}" "$edad" \
      "${COL[$n_cpu]}" "$graf" "$RST" \
      "${COL[$n_glob]}" "${NOMBRE[$n_glob]}" "$RST"
  fi
}

# ---------- salida web ----------
html_cabecera() {
  cat <<EOF
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta http-equiv="refresh" content="$REFRESCO">
<title>Monitor de recursos</title>
<style>
  body { font-family: sans-serif; background: #111; color: #eee; margin: 2em; }
  h1 { font-size: 1.4em; }
  small { color: #999; }
  table { border-collapse: collapse; width: 100%; }
  th, td { padding: 8px 12px; text-align: left; border-bottom: 1px solid #333; }
  th { color: #aaa; font-weight: normal; }
  .n0 { color: #fff; background: #1f7a3a; }
  .n1 { color: #000; background: #e0b400; }
  .n2 { color: #fff; background: #c0392b; }
  .graf { font-family: monospace; letter-spacing: 1px; }
  .caido td { color: #888; background: #222; }
  .est { font-weight: bold; }
</style>
</head>
<body>
<h1>Monitor de recursos</h1>
<small>Actualizado $(date '+%H:%M:%S') &middot; amarillo &ge; ${U_AMA}% &middot; rojo &gt; ${U_ROJO}% &middot; caido &gt; ${U_CAIDO}s</small>
<table>
<tr><th>Host</th><th>CPU</th><th>Mem</th><th>Disco /</th><th>Carga</th><th>Hora</th><th>Edad</th><th>CPU (20)</th><th>Estado</th></tr>
EOF
}

html_pie() {
  printf '</table>\n</body>\n</html>\n'
}

fila_html() {   # usa las variables de procesar()
  local h; h=$(esc "$host")
  if (( n_glob == 3 )); then
    printf '<tr class="caido"><td>%s</td><td colspan="7">ultimo informe hace %ss (%s)</td><td class="est">CAIDO</td></tr>\n' \
      "$h" "$edad" "${ts:11:8}"
  else
    printf '<tr><td>%s</td><td class="n%s">%.1f%%</td><td class="n%s">%.1f%%</td><td class="n%s">%.0f%%</td><td>%.2f</td><td>%s</td><td>%ss</td><td class="graf">%s</td><td class="est n%s">%s</td></tr>\n' \
      "$h" "$n_cpu" "$cpu" "$n_mem" "$mem" "$n_dis" "$disco" "$carga" "${ts:11:8}" "$edad" "$graf" \
      "$n_glob" "${NOMBRE[$n_glob]}"
  fi
}

# ---------- logica comun: niveles, alertas y una fila por host ----------
procesar() {
  local host cpu mem disco carga ts edad graf n_cpu n_mem n_dis n_glob prev
  while IFS=$'\t' read -r host cpu mem disco carga ts edad graf; do
    [[ -z $host ]] && continue
    n_cpu=$(nivel "$cpu"); n_mem=$(nivel "$mem"); n_dis=$(nivel "$disco")
    n_glob=$n_cpu; (( n_mem > n_glob )) && n_glob=$n_mem; (( n_dis > n_glob )) && n_glob=$n_dis
    (( edad > U_CAIDO )) && n_glob=3

    # alerta solo si cambia el estado
    prev=${ESTADO[$host]:-0}
    if [[ $prev != "$n_glob" ]]; then
      alertar "$host" "$prev" "$n_glob" "$cpu" "$mem" &
      ESTADO[$host]=$n_glob
    fi

    if [[ $MODO == html ]]; then fila_html; else fila_term; fi
  done <<< "$1"
}

limpiar() { rm -f "$TMP"; [[ $MODO == terminal ]] && tput cnorm; echo; exit 0; }
trap limpiar INT TERM

if [[ $MODO == html ]]; then
  mkdir -p "$SALIDA_DIR" || exit 1
  echo "Modo web: escribiendo $SALIDA_DIR/index.html cada ${REFRESCO}s (Ctrl+C para parar)"
else
  tput civis
fi

while true; do
  cargar_umbrales
  if ! datos=$(curl -sS -f -m 5 "$CANAL_URL" 2>&1); then
    log "ERROR consultando el canal: $datos"
    if [[ $MODO == html ]]; then
      echo "$(date +%T) no se puede leer el canal ($CANAL_URL)"
    else
      printf '\033[H\033[JNo se puede leer el canal (%s). Reintentando...\n' "$CANAL_URL"
    fi
    sleep "$REFRESCO"; continue
  fi
  filas=$(jq -r --argjson now "$(date +%s)" "$FILTRO" <<< "$datos" 2>>"$LOG")

  # IMPORTANTE: se redirige un grupo { } (no $(...)) para que procesar() corra en el
  # shell principal y ESTADO se conserve entre ciclos; si no, las alertas se repetirian.
  if [[ $MODO == html ]]; then
    { html_cabecera; procesar "$filas"; html_pie; } > "$SALIDA_DIR/.index.tmp" \
      && mv "$SALIDA_DIR/.index.tmp" "$SALIDA_DIR/index.html"
    echo "$(date +%T) index.html actualizado"
  else
    { term_cabecera; procesar "$filas"; } > "$TMP"
    printf '\033[H\033[J'; cat "$TMP"
  fi
  sleep "$REFRESCO"
done
