#!/usr/bin/env python3
"""receptor.py - canal local para el ejercicio de monitorizacion.

  POST /webhook/<canal>   guarda el JSON recibido en ese canal (monitor, alertas...)
  GET  /canal/<canal>     devuelve una lista JSON: [{"canal":..., "recibido":..., "datos": {...}}, ...]

Uso: python3 receptor.py [--bind 127.0.0.1] [--port 8080]
"""
import argparse
import json
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MAX_POR_CANAL = 2000
canales = {}
cerrojo = threading.Lock()


class Manejador(BaseHTTPRequestHandler):
    def _responder(self, codigo, cuerpo):
        datos = json.dumps(cuerpo, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(datos)))
        self.end_headers()
        self.wfile.write(datos)

    def do_POST(self):
        partes = self.path.strip("/").split("/")
        if len(partes) != 2 or partes[0] != "webhook":
            return self._responder(404, {"error": "usa POST /webhook/<canal>"})
        longitud = int(self.headers.get("Content-Length", 0))
        try:
            datos = json.loads(self.rfile.read(longitud))
        except (ValueError, UnicodeDecodeError):
            return self._responder(400, {"error": "JSON no valido"})
        registro = {
            "canal": partes[1],
            "recibido": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "datos": datos,
        }
        with cerrojo:
            lista = canales.setdefault(partes[1], [])
            lista.append(registro)
            del lista[:-MAX_POR_CANAL]
        self._responder(200, {"ok": True})

    def do_GET(self):
        partes = self.path.strip("/").split("/")
        if len(partes) != 2 or partes[0] != "canal":
            return self._responder(404, {"error": "usa GET /canal/<canal>"})
        with cerrojo:
            lista = list(canales.get(partes[1], []))
        self._responder(200, lista)

    def log_message(self, formato, *args):
        print("%s %s" % (datetime.now().strftime("%H:%M:%S"), formato % args))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--bind", default="127.0.0.1", help="0.0.0.0 para aceptar otros equipos")
    ap.add_argument("--port", type=int, default=8080)
    a = ap.parse_args()
    print("Receptor en http://%s:%d  (Ctrl+C para parar)" % (a.bind, a.port))
    ThreadingHTTPServer((a.bind, a.port), Manejador).serve_forever()
